# Bratislava Taxi Driver – Android

Natívna Android aplikácia kompatibilná so súčasným FastAPI taxi serverom.

## Funkcie

- nastaviteľná adresa servera,
- načítanie vodičov z `/api/drivers`,
- GPS cez natívnu Android službu,
- odosielanie polohy približne každú 1 sekundu,
- funguje aj cez lokálne HTTP,
- GPS pokračuje pri zhasnutej obrazovke ako foreground service,
- prijímanie objednávok,
- stavy Voľný / Pauza / Offline,
- Prichádzam / Zákazník nastúpil / Jazda ukončená,
- spustenie navigácie v Google Maps.

## Ako vytvoriť APK

1. Nainštaluj Android Studio.
2. Otvor tento priečinok cez **Open**.
3. Počkaj na dokončenie Gradle Sync.
4. Pripoj Android telefón s USB debugging alebo použi emulátor.
5. Klikni **Run**.

Na vytvorenie APK:

`Build` → `Build App Bundles or APKs` → `Build APKs`

Výsledok bude približne v:

`app/build/outputs/apk/debug/app-debug.apk`

## Nastavenie servera

V aplikácii zadaj adresu telefónu alebo PC, na ktorom beží Termux server, napríklad:

`http://192.168.0.248:8000`

Telefón vodiča a server musia byť na rovnakej Wi-Fi, pokiaľ server ešte nie je verejne dostupný.

## Android nastavenia

Po inštalácii povoľ:

- presnú polohu,
- upozornenia,
- polohu počas používania aplikácie,
- batériu nastaviť na **Bez obmedzení**.

Aplikácia používa existujúce endpointy servera, preto backend netreba meniť.
